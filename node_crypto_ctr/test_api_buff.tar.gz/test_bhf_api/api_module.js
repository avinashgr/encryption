var DEBUG = {};
var encodeDecodeUtil = {};

encodeDecodeUtil.decodeMessage = function(str){
  return Buffer.from(str, 'base64');
}
encodeDecodeUtil.encodeMessage = function(str){
  return Buffer.toString(str, 'base64');
}
DEBUG.write =  function(text){
 console.log(text);
}

var unirest = require("./node_modules/unirest");

var token = "";
async function runAPI(apiInfo,tokenInfo){
  token = await(invoke(tokenInfo));
  apiInfo.headers.Authorization="Bearer "+token.access_token;
  payload = await(invoke(apiInfo));
  return payload;
}

var invoke = async function(apiInfo){  
  return new Promise((resolve,reject) => invokeAPI(resolve,reject,apiInfo));
}


var invokeAPI = function(resolve,reject,apiInfo){

  var req = unirest(apiInfo.verb, apiInfo.url);

  req.headers(apiInfo.headers);
  
  req.send(apiInfo.body)
  
  req.end(function (res) {
    console.log("The response for the call %s for %s is success!",apiInfo.url, apiInfo.verb);
    if (res.error) {
      console.log("The error is: %s",res.error);
    }
    console.log("The response http code %s", res.statusCode);
    if(res.statusCode ==  204){
      return resolve("");
    }
    return resolve(res.body);
  });
  // var token = body.access_token;
  // return token;
}


module.exports.runAPI = runAPI;

DEBUG.write = function(text){
  console.log(text);
}





