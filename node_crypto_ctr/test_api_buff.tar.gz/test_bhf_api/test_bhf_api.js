var api = require ("./api_module");
var encrypt = require ("./encryption/encrypt_ctr");
const ENCRYPTION_KEY = "dMmam5dOb6+DTTmo2CLGXjnvlCm0KgIZrNZfRXt8L3E=";
var tokenInfo = {
    headers:
    {
        "Accept": "*/*",
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": "Basic MzJXbDVGWVdzTTdlbTg3aHNpTUM3dEdHeWlMb3Nta2E6ZzdtdTBWa0UwSlF2WU8xVw=="
    },
    url: "https://bhf-test.apimanagement.us2.hana.ondemand.com/v1/OAuthServiceCC/GenerateToken",
    verb: "POST",
    body:
    {
        "grant_type": "client_credentials",
        "scope": "all"
    }
};

var isValidWholesalerDocument = {
    name:"orgInfo",
    headers:
    {
        "Authorization": ""
    },
    url: "https://bhf-test.apimanagement.us2.hana.ondemand.com/BHFCustomer/isValidWholesalerDocument",
    verb: "POST",
    body: {"DocumentId":"61F7200E064F400EA4219E5598122E68"}

};
var upsertRegisterUser = {
    name: "upsertRegisterUser",
	headers:
    {
        "Content-Type": "application/json",
        "Authorization": ""
    },
	url: "https://bhf-test.apimanagement.us2.hana.ondemand.com/BHFCustomer/upsertRegisterUser",
	verb: "POST",
	body: {"EIAMID":"5599FE4E8B25428FAB6BA72A2A6269CA","phonereg":"2485507400"}
};
var searchProvisionalBOA = {
    name:"orgInfo",
    headers:
    {
	    "Content-Type": "application/json",
        "Authorization": ""
    },
    url: "https://bhf-test.apimanagement.us2.hana.ondemand.com/BHFCustomer/searchProvisionalBOA",
    verb: "POST",
    body: {"registrationToken": "41D19EB038582C00F0000004B80C6300","lastName": "Moreno","emailddress": "dmmoreno51@gmail.com"}

};
var isValidPolicyID = {
    name:"orgInfo",
    headers:
    {
	    "Content-Type": "application/json",
        "Authorization": ""
    },
    url: "https://bhf-test.apimanagement.us2.hana.ondemand.com/BHFCustomer/isValidPolicyID",
    verb: "POST",
    body: {"EIAMID":"0E1CB60974EB42EB8A27FE48732EC2BB","PolicyIds":"3400000017"}

};
// csutomer test data
// 145626311||06/07/1942||HASAN||7400000202
// 276722636||02/28/1970||FROELICH||3200045597
// 483566733||05/04/1945||HALTERMAN||1100594045
// 423944902||10/05/1961||GORDON||3200044996

var searchCustomer = {
    name:"orgInfo",
    headers:
    {
        "Authorization": ""
    },
    url: "https://bhf-test.apimanagement.us2.hana.ondemand.com/BHFCustomer/searchCustomer",
    verb: "POST",
    body: {"PolicyNumberReq":"3200044996","SsnReq":"423944902","LastNameReq":"GORDON","DateOfBirthReq":"10/05/1961"}

};
// 084380274||07/02/1948||LEVIS||qmotestaddress2@gmail.com
// 180666790||03/05/1980||LEONARD||qmotestaddress3@gmail.com
// 221625683||06/01/1966||POORE||qmotestaddress4@gmail.com
// 526965136||12/26/1951||LESTER||qmotestaddress5@gmail.com
//72641593||1585840||5/30/1968||MATTHEW||LAURENCE||qmotestaddress1@gmail.com
//84380274||419054||7/2/1948||PAUL||LEVIS||qmotestaddress2@gmail.com
//180666790||8055671||3/5/1980||MARTIN||LEONARD||qmotestaddress3@gmail.com
//221625683||2061408||6/1/1966||KAREN||POORE||qmotestaddress4@gmail.com
//526965136||933155||12/26/1951||ROBERT||LESTER||qmotestaddress5@gmail.com
//552596684||8550897||5/24/1965||MARIA||GUTIERREZ||qmotestaddress6@gmail.com
//189361104||754601||11/19/1947||ROBERT||HARCLERODE||qmotestaddress7@gmail.com



var searchAgent = {
    name:"orgInfo",
    headers:
    {
        "Authorization": ""
    },
    url: "https://bhf-test.apimanagement.us2.hana.ondemand.com//BHFCustomer/searchAgent",
    verb: "POST",
    body: {"SsnReq":"301882012","EmailAddressReq":"qmotestaddress96@gmail.com","LastNameReq":"Simmons","DateOfBirthReq":"08/07/1983"}

};
//example:{"EiamIdReq":"61F7200E064F400EA4219E5598122E68"}
var getUserInfo = {
    name:"orgInfo",
    headers:
    {
        "Authorization": ""
    },
    url: "https://bhf-test.apimanagement.us2.hana.ondemand.com/BHFCustomer/getUserInfo",
    verb: "POST",
    body: {"EiamIdReq":"F1B4A6C37618481F9BA7A1FABDEA4FB3"}

};

var isValidDocumentId= {
    name:"orgInfo",
    headers:
    {
        "Authorization": ""
    },
    verb: "POST",
    url: "https://bhf-test.apimanagement.us2.hana.ondemand.com/BHFCustomer/isValidDocumentIDs",
    body: {"EiamId":"F1B4A6C37618481F9BA7A1FABDEA4FB3","DocumentIds":"b01b1dc03246bd1ce59a577298dc547a3c091eedb95da625575ed4c149f634fa"}
};
    

main();
async function main(){
   var args = process.argv.slice(2);
   var result = await processAPICall(eval(args[0]));
   console.log("result %s",result);  
}

async function processAPICall(testapi) {
    console.log("the body is: %j", testapi.body);
    var body = JSON.stringify(testapi.body);
    var encrypted = await encrypt.encrypt(body,ENCRYPTION_KEY);
    console.log("the body is: %s",encrypted);
    testapi.body = encrypted;
    var result = await api.runAPI(testapi, tokenInfo);
	console.log("the response is: %s", JSON.stringify(result));
    if(String(result).trim().length>0){
        var decrypted = await encrypt.decrypt(result,ENCRYPTION_KEY);
        return decrypted;
    }else{
        return "nothing to decrypt";
    }

}

